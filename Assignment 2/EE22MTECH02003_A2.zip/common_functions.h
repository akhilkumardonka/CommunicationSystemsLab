#include <stdio.h>

float* lpf(int fc, int fs, int N); 

float* bpf(int fc1, int fc2, int fs, int N); 